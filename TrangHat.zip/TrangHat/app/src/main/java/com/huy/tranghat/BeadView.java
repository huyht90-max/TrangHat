package com.huy.tranghat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.Arrays;
import java.util.Comparator;

/** Vòng tràng hạt 3D: các hạt nằm trên một vòng tròn nghiêng, chiếu phối cảnh. */
public class BeadView extends View {

    public interface Listener { void onCount(long total, int delta); }

    static final int SLOTS = 36;                       // số hạt hiển thị trên vòng
    static final double STEP = 2 * Math.PI / SLOTS;
    static final double TILT = Math.toRadians(30);     // độ nghiêng của vòng
    static final int MALA = 108;

    // {sáng, gốc, tối}
    static final int[][] MATS = {
            {0xFFC98A55, 0xFF7A4524, 0xFF2A140A},   // Gỗ trầm
            {0xFFF3E6C4, 0xFFC9A86E, 0xFF5E4524},   // Bồ đề
            {0xFF9FE0B8, 0xFF2F8A5A, 0xFF0B2E1D},   // Ngọc bích
            {0xFFF08A7A, 0xFFA3261E, 0xFF3A0806},   // Mã não
            {0xFFD9B8F2, 0xFF7B3FA8, 0xFF26103A},   // Thạch anh tím
    };
    static final String[] NAMES = {"Gỗ trầm", "Bồ đề", "Ngọc bích", "Mã não", "Thạch anh"};
    static final int[] GURU = {0xFFFFF1B8, 0xFFD4A437, 0xFF4A2E06};

    private Listener listener;
    private int material = 0;

    private double p = 0, v = 0, target = Double.NaN, prevTarget = Double.NaN;
    private long lastCount = 0;
    private long lastNanos = 0;
    private boolean dragging, moved;
    private float lastY, downX, downY;
    private VelocityTracker vt;
    private final int slop;

    private float cx, cy, R, D, baseR, spacing, sMin, sMax;

    private final Paint bgPaint = new Paint();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint beadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint specPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint threadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final float[] px = new float[SLOTS], py = new float[SLOTS], ps = new float[SLOTS], pz = new float[SLOTS];
    private final long[] pk = new long[SLOTS];

    private static class Item { boolean bead; float depth; int a, b; }
    private final Item[] items = new Item[SLOTS * 2];
    private final Comparator<Item> byDepth = new Comparator<Item>() {
        @Override public int compare(Item x, Item y) { return Float.compare(x.depth, y.depth); }
    };

    public BeadView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        for (int i = 0; i < items.length; i++) items[i] = new Item();
        threadPaint.setStyle(Paint.Style.STROKE);
        threadPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setListener(Listener l) { listener = l; }
    public void setMaterial(int m) { material = m; invalidate(); }

    public void setPosition(long total) {
        p = total; v = 0; target = Double.NaN; lastCount = total; invalidate();
    }

    /** Lần thêm 1 hạt (có hoạt ảnh). */
    public void advance() {
        target = (Double.isNaN(target) ? Math.round(p) : target) + 1;
        v = 0;
        lastNanos = 0;
        postInvalidateOnAnimation();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        R = Math.min(h * 0.36f, w * 0.58f);
        cx = w * 0.42f;
        cy = h * 0.52f;
        D = 3f * R;
        float zc = (float) (R * Math.cos(TILT));
        sMax = D / (D - zc);
        sMin = D / (D + zc);
        baseR = (float) (R * STEP * 0.46);
        spacing = (float) (R * STEP * sMax);
        bgPaint.setShader(new LinearGradient(0, 0, 0, h, 0xFF1E1610, 0xFF040302, Shader.TileMode.CLAMP));
        float fx = cx + (float) (R * Math.sin(TILT)) * sMax;
        glowPaint.setShader(new RadialGradient(fx, cy, R * 1.1f,
                new int[]{0x40D9A066, 0x14D9A066, 0x00000000}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
    }

    // ---------- vật lý ----------
    private boolean step(float dt) {
        if (dragging) { checkCount(); return true; }
        if (Double.isNaN(target)) {
            p += v * dt;
            v *= Math.exp(-2.2 * dt);
            if (p < 0) { p = 0; v = 0; }
            if (Math.abs(v) < 2.0) target = Math.max(0, Math.round(p + v * 0.12));
        }
        if (!Double.isNaN(target)) {
            double a = (target - p) * 90 - v * 16;
            v += a * dt;
            p += v * dt;
            if (Math.abs(target - p) < 0.001 && Math.abs(v) < 0.02) {
                p = target; v = 0; target = Double.NaN;
                checkCount();
                return false;
            }
        }
        checkCount();
        return true;
    }

    private void checkCount() {
        long c = (long) Math.floor(p + 0.5);
        if (c != lastCount) {
            int d = (int) (c - lastCount);
            lastCount = c;
            if (listener != null) listener.onCount(c, d);
        }
    }

    // ---------- chạm ----------
    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true; moved = false;
                downX = e.getX(); downY = e.getY(); lastY = downY;
                prevTarget = target;
                v = 0; target = Double.NaN;
                if (vt != null) vt.recycle();
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                lastNanos = 0;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                postInvalidateOnAnimation();
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (vt != null) vt.addMovement(e);
                float y = e.getY();
                if (!moved && (Math.abs(y - downY) > slop || Math.abs(e.getX() - downX) > slop)) {
                    moved = true; lastY = y;
                }
                if (moved) {
                    p += (y - lastY) / spacing;
                    if (p < 0) p = 0;
                    lastY = y;
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                dragging = false;
                float vy = 0;
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    vy = vt.getYVelocity();
                    vt.recycle(); vt = null;
                }
                if (!moved && e.getActionMasked() == MotionEvent.ACTION_UP) {
                    target = (Double.isNaN(prevTarget) ? Math.round(p) : prevTarget) + 1;
                    v = 0;
                } else {
                    v = Math.max(-30, Math.min(30, vy / spacing));
                    target = Double.NaN;
                }
                lastNanos = 0;
                postInvalidateOnAnimation();
                return true;
            }
        }
        return super.onTouchEvent(e);
    }

    // ---------- vẽ ----------
    @Override protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.05f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        boolean animating = step(dt);

        int w = getWidth(), h = getHeight();
        canvas.drawRect(0, 0, w, h, bgPaint);
        canvas.drawRect(0, 0, w, h, glowPaint);

        long c = Math.round(p);
        double sinT = Math.sin(TILT), cosT = Math.cos(TILT);
        for (int i = 0; i < SLOTS; i++) {
            long k = c + i - SLOTS / 2;
            double th = (p - k) * STEP;
            double X = R * Math.cos(th) * sinT;
            double Y = R * Math.sin(th);
            double Z = R * Math.cos(th) * cosT;
            float s = (float) (D / (D - Z));
            px[i] = cx + (float) X * s;
            py[i] = cy + (float) Y * s;
            ps[i] = s;
            pz[i] = (float) Z;
            pk[i] = k;
        }

        int n = 0;
        for (int i = 0; i < SLOTS; i++) {
            Item it = items[n++];
            it.bead = true; it.a = i; it.depth = pz[i];
            int j = (i + 1) % SLOTS;
            Item t = items[n++];
            t.bead = false; t.a = i; t.b = j; t.depth = Math.min(pz[i], pz[j]) - 1f;
        }
        Arrays.sort(items, 0, n, byDepth);

        for (int q = 0; q < n; q++) {
            Item it = items[q];
            if (it.bead) {
                int i = it.a;
                boolean guru = Math.floorMod(pk[i], (long) MALA) == 0;
                float r = baseR * ps[i] * (guru ? 1.3f : 1f);
                float closeness = (float) Math.max(0, 1 - Math.abs(p - pk[i]));
                drawBead(canvas, px[i], py[i], r, guru ? GURU : MATS[material], bright(ps[i]), closeness);
            } else {
                float s = (ps[it.a] + ps[it.b]) * 0.5f;
                threadPaint.setStrokeWidth(baseR * 0.2f * s);
                threadPaint.setColor(shade(0xFF7A2418, bright(s)));
                canvas.drawLine(px[it.a], py[it.a], px[it.b], py[it.b], threadPaint);
            }
        }

        if (animating || dragging) postInvalidateOnAnimation();
        else lastNanos = 0;
    }

    private float bright(float s) {
        float t = (s - sMin) / (sMax - sMin);
        t = Math.max(0, Math.min(1, t));
        return 0.25f + 0.75f * (float) Math.pow(t, 1.3);
    }

    private void drawBead(Canvas c, float x, float y, float r, int[] m, float b, float front) {
        if (front > 0.01f) {
            haloPaint.setShader(new RadialGradient(x, y, r * 2.2f,
                    new int[]{Color.argb((int) (90 * front), 255, 200, 120), 0x00000000},
                    null, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, r * 2.2f, haloPaint);
        }
        int light = shade(m[0], b), base = shade(m[1], b), dark = shade(m[2], b);
        int deep = shade(m[2], b * 0.45f);
        beadPaint.setShader(new RadialGradient(x - r * 0.35f, y - r * 0.4f, r * 1.45f,
                new int[]{light, base, dark, deep}, new float[]{0f, 0.38f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, beadPaint);

        // ánh phản quang phía dưới-phải
        rimPaint.setShader(new RadialGradient(x + r * 0.35f, y + r * 0.5f, r * 0.85f,
                new int[]{withAlpha(m[0], (int) (75 * b)), 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, rimPaint);

        // điểm sáng bóng
        float sx = x - r * 0.36f, sy = y - r * 0.42f, sr = r * 0.4f;
        specPaint.setShader(new RadialGradient(sx, sy, sr,
                new int[]{Color.argb((int) (235 * b), 255, 255, 250), Color.argb((int) (60 * b), 255, 255, 250), 0x00FFFFFF},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, sr, specPaint);
    }

    private static int shade(int c, float f) {
        return Color.argb(Color.alpha(c),
                Math.min(255, (int) (Color.red(c) * f)),
                Math.min(255, (int) (Color.green(c) * f)),
                Math.min(255, (int) (Color.blue(c) * f)));
    }

    private static int withAlpha(int c, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0x00FFFFFF);
    }
}
