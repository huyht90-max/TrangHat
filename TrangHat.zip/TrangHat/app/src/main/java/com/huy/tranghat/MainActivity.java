package com.huy.tranghat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends Activity implements BeadView.Listener {

    private BeadView beads;
    private TextView tvCount, tvInfo, bSound, bVib, bMat;
    private SoundPool pool;
    private final int[] clicks = new int[3];
    private int bell;
    private SharedPreferences prefs;
    private boolean soundOn, vibOn;
    private int material;
    private Vibrator vib;
    private final Random rnd = new Random();
    private long lastClickMs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences("tranghat", MODE_PRIVATE);
        soundOn = prefs.getBoolean("sound", true);
        vibOn = prefs.getBoolean("vib", true);
        material = prefs.getInt("mat", 0);
        long total = prefs.getLong("total", 0);

        pool = new SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .build();
        clicks[0] = pool.load(this, R.raw.click1, 1);
        clicks[1] = pool.load(this, R.raw.click2, 1);
        clicks[2] = pool.load(this, R.raw.click3, 1);
        bell = pool.load(this, R.raw.bell, 1);
        vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        FrameLayout root = new FrameLayout(this);
        beads = new BeadView(this);
        beads.setListener(this);
        beads.setMaterial(material);
        beads.setPosition(total);
        root.addView(beads, new FrameLayout.LayoutParams(-1, -1));

        // --- bộ đếm ---
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(26), dp(36), dp(26), 0);
        tvCount = new TextView(this);
        tvCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 76);
        tvCount.setTextColor(0xFFF2E3C6);
        tvCount.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        tvCount.setShadowLayer(dp(14), 0, 0, 0x88D9A066);
        tvInfo = new TextView(this);
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvInfo.setTextColor(0xFFB09A7C);
        tvInfo.setTypeface(Typeface.SERIF);
        TextView hint = new TextView(this);
        hint.setText("Vuốt xuống để lần hạt\nChạm để lần một hạt\nGiữ rồi kéo ngang để xoay");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        hint.setTextColor(0x66E8D9BC);
        hint.setPadding(0, dp(10), 0, 0);
        top.addView(tvCount);
        top.addView(tvInfo);
        top.addView(hint);
        tvCount.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { confirmReset(); return true; }
        });
        root.addView(top, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));

        // --- thanh nút ---
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(10), 0, dp(10), dp(18));
        bSound = makeButton(bar);
        bVib = makeButton(bar);
        bMat = makeButton(bar);
        TextView bReset = makeButton(bar);
        bReset.setText("Đặt lại");
        bSound.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                soundOn = !soundOn; prefs.edit().putBoolean("sound", soundOn).apply(); refreshButtons();
            }
        });
        bVib.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                vibOn = !vibOn; prefs.edit().putBoolean("vib", vibOn).apply(); refreshButtons();
            }
        });
        bMat.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                material = (material + 1) % BeadView.NAMES.length;
                prefs.edit().putInt("mat", material).apply();
                beads.setMaterial(material); refreshButtons();
            }
        });
        bReset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmReset(); }
        });
        root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        setContentView(root);
        refreshButtons();
        updateLabels(total);
    }

    private TextView makeButton(LinearLayout bar) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTextColor(0xFFE8D9BC);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(11), dp(6), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x1FFFFFFF);
        g.setCornerRadius(dp(22));
        g.setStroke(dp(1), 0x33E8D9BC);
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        bar.addView(t, lp);
        return t;
    }

    private void refreshButtons() {
        bSound.setText(soundOn ? "🔔 Tiếng" : "🔕 Tắt tiếng");
        bVib.setText(vibOn ? "📳 Rung" : "Tắt rung");
        bMat.setText(BeadView.NAMES[material]);
    }

    private void updateLabels(long total) {
        long inRound = Math.floorMod(total, (long) BeadView.MALA);
        long shown = (inRound == 0 && total > 0) ? BeadView.MALA : inRound;
        long rounds = Math.floorDiv(total, (long) BeadView.MALA);
        tvCount.setText(String.valueOf(shown));
        tvInfo.setText("/ 108   ·   Vòng " + rounds + "   ·   Tổng " + total);
    }

    private void confirmReset() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Đặt lại bộ đếm?")
                .setMessage("Số hạt và số vòng sẽ về 0.")
                .setNegativeButton("Huỷ", null)
                .setPositiveButton("Đặt lại", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putLong("total", 0).apply();
                        beads.setPosition(0);
                        updateLabels(0);
                    }
                }).show();
    }

    @Override public void onCount(long total, int delta) {
        boolean done = delta > 0 &&
                Math.floorDiv(total, (long) BeadView.MALA) > Math.floorDiv(total - delta, (long) BeadView.MALA);
        if (soundOn) {
            if (done) pool.play(bell, 1f, 1f, 2, 0, 1f);
            long now = SystemClock.uptimeMillis();
            if (now - lastClickMs > 35) {
                lastClickMs = now;
                float rate = 0.93f + rnd.nextFloat() * 0.14f;
                float vol = delta > 0 ? 1f : 0.55f;
                pool.play(clicks[rnd.nextInt(3)], vol, vol, 1, 0, rate);
            }
        }
        if (vibOn) vibrate(done);
        prefs.edit().putLong("total", total).apply();
        updateLabels(total);
        if (done) {
            tvCount.animate().cancel();
            tvCount.setScaleX(1.35f); tvCount.setScaleY(1.35f);
            tvCount.animate().scaleX(1f).scaleY(1f).setDuration(700).start();
        }
    }

    @SuppressWarnings("deprecation")
    private void vibrate(boolean strong) {
        if (vib == null || !vib.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 29) {
            vib.vibrate(VibrationEffect.createPredefined(
                    strong ? VibrationEffect.EFFECT_HEAVY_CLICK : VibrationEffect.EFFECT_TICK));
        } else if (Build.VERSION.SDK_INT >= 26) {
            vib.vibrate(VibrationEffect.createOneShot(strong ? 60 : 12, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vib.vibrate(strong ? 60 : 12);
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (pool != null) pool.release();
    }
}
